export interface ContentSnippet {
    key: string;
    lang: 'en' | 'sv';
    body: string;
}

export interface AIChange {
    matchFound: boolean;
    key: string | null;
    confidence: number;
    newContent: string | null;
    reasoning: string;
}

export interface AIResponse {
    changes: AIChange[];
    summaryReasoning: string;
}
