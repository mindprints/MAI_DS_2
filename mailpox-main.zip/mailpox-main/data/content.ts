import type { ContentSnippet } from '../types';

export const initialContent: ContentSnippet[] = [
    {
        key: 'page.demo.title',
        lang: 'en',
        body: '<h1 class="text-3xl font-bold text-gray-800 border-b pb-2 mb-4">Demo Edit Test Page</h1>'
    },
    {
        key: 'page.demo.welcome.title',
        lang: 'en',
        body: '<h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-2">Welcome Section</h2>'
    },
    {
        key: 'page.demo.welcome.p1',
        lang: 'en',
        body: '<p class="text-base text-gray-600 leading-relaxed">This is an introductory paragraph with some <strong>bold text</strong> and <em>italic text</em> that can be edited via email.</p>'
    },
    {
        key: 'page.demo.multi.title',
        lang: 'en',
        body: '<h2 class="text-2xl font-semibold text-gray-700 mt-6 mb-2">Multi-paragraph Section</h2>'
    },
    {
        key: 'page.demo.multi.p1',
        lang: 'en',
        body: '<p class="text-base text-gray-600 leading-relaxed">First paragraph with a deliberate typo: "teh quick brown fox". This is a great candidate for your first edit!</p>'
    },
    {
        key: 'page.demo.multi.p2',
        lang: 'en',
        body: '<p class="text-base text-gray-600 leading-relaxed">Second paragraph with a <a href="#" onclick="return false;" class="text-blue-600 hover:underline">link to About page</a>. You can try changing the link text or its (dummy) destination.</p>'
    },
    {
        key: 'page.demo.list.title',
        lang: 'en',
        body: '<h3 class="text-xl font-medium text-gray-700 mt-6 mb-2">Lists Test</h3>'
    },
    {
        key: 'page.demo.list.ul',
        lang: 'en',
        body: '<ul class="list-disc list-inside space-y-1 text-gray-600"><li>First item</li><li>Second item</li><li>Third item</li></ul>'
    },
    {
        key: 'page.demo.swedish.title',
        lang: 'sv',
        body: '<h2 class="text-2xl font-semibold text-gray-700 mt-8 mb-2 border-t pt-4">Swedish Content Test (Svenska)</h2>'
    },
    {
        key: 'page.demo.swedish.p1',
        lang: 'sv',
        body: '<p class="text-base text-gray-600 leading-relaxed">Detta är svensk text för att testa flerspråkig redigering. (This is Swedish text to test multilingual editing.)</p>'
    }
];
