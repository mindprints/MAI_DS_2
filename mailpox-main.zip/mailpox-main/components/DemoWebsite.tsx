import React from 'react';
import DOMPurify from 'dompurify';
import type { ContentSnippet } from '../types';

interface DemoWebsiteProps {
    content: ContentSnippet[];
}

export const DemoWebsite: React.FC<DemoWebsiteProps> = ({ content }) => {
    return (
        <div className="bg-gray-100 rounded-lg p-6 shadow-inner border border-gray-300">
            {content.map(snippet => {
                const cleanHtml = DOMPurify.sanitize(snippet.body, {
                    ALLOWED_TAGS: ['h1', 'h2', 'h3', 'p', 'strong', 'em', 'ul', 'li', 'a'],
                    ALLOWED_ATTR: ['href', 'class', 'onclick']
                });
                return <div key={snippet.key} dangerouslySetInnerHTML={{ __html: cleanHtml }} />;
            })}
        </div>
    );
};
