<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1sCkZ1K5m0EJ2FVKiQPBDt37miHYoKqQh

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## How it Works

This application demonstrates a novel approach to website content management. The core premise is to allow content updates via a simulated email editor, without requiring any special software on the client side.

Here's the workflow:

1.  **Copy Content:** A user copies a snippet of text from the demo website. Modern web browsers and email clients preserve the underlying HTML formatting (e.g., lists, links, bold text) during the copy-paste process.
2.  **Edit in Email:** The user pastes the copied content into the simulated email editor and makes their desired changes directly.
3.  **Send Email:** The user "sends" the email.
4.  **AI-Powered Updates:** The application sends the email body to a server-side AI (powered by the Gemini API). This AI is responsible for:
    *   **Identifying the original content:** The AI compares the edited text to the website's existing content to determine which snippet was modified. This is done without any special IDs or hidden markers.
    *   **Applying the changes:** The AI intelligently merges the user's edits into the original content, preserving the HTML structure.
    *   **Updating the website:** The updated content is then reflected on the demo website.

This system is designed to be simple and intuitive for non-technical users, while leveraging the power of AI to handle the complex task of identifying and applying content changes.
