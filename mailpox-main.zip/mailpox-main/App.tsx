import React, { useState, useCallback } from 'react';
import { DemoWebsite } from './components/DemoWebsite';
import { EmailEditor } from './components/EmailEditor';
import { processEdit } from './services/geminiService';
import { initialContent } from './data/content';
import type { ContentSnippet, AIResponse, AIChange } from './types';
import { LogoIcon, RefreshIcon } from './components/Icons';

const App: React.FC = () => {
    const [content, setContent] = useState<ContentSnippet[]>(initialContent);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
    const [editorResetCounter, setEditorResetCounter] = useState(0);

    const handleSendEmail = useCallback(async (emailBody: string) => {
        setIsLoading(true);
        setStatusMessage({ type: 'info', text: 'Analyzing your edit request with AI...' });

        try {
            const responseJson = await processEdit(content, emailBody);
            
            let successfulUpdates = 0;
            let lowConfidenceCount = 0;
            let notFoundCount = 0;

            let updatedContent = [...content]; // Create a mutable copy

            responseJson.changes.forEach((change: AIChange) => {
                if (change.matchFound && change.key && change.newContent) {
                    if (change.confidence < 0.7) {
                        lowConfidenceCount++;
                    } else {
                        const index = updatedContent.findIndex(snippet => snippet.key === change.key);
                        if (index !== -1) {
                            updatedContent[index] = { ...updatedContent[index], body: change.newContent! };
                            successfulUpdates++;
                        }
                    }
                } else {
                    notFoundCount++;
                }
            });

            setContent(updatedContent); // Apply all successful changes at once

            // Construct a status message
            let statusText = `AI Analysis: ${responseJson.summaryReasoning}. `;
            statusText += `Applied ${successfulUpdates} update(s). `;
            if (lowConfidenceCount > 0) statusText += `${lowConfidenceCount} match(es) had low confidence. `;
            if (notFoundCount > 0) statusText += `${notFoundCount} snippet(s) could not be matched.`;

            const messageType = successfulUpdates > 0 ? 'success' : (notFoundCount > 0 || lowConfidenceCount > 0) ? 'error' : 'info';
            setStatusMessage({ type: messageType, text: statusText.trim() });
            
        } catch (error) {
            console.error("Error processing edit:", error);
            const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
            setStatusMessage({ type: 'error', text: `Failed to process edit. ${errorMessage}` });
        } finally {
            setIsLoading(false);
        }
    }, [content]);

    const handleResetContent = useCallback(() => {
        setContent(initialContent);
        setEditorResetCounter(c => c + 1);
        setStatusMessage({ type: 'info', text: 'Website content and editor have been reset.' });
    }, []);

    return (
        <div className="bg-gray-900 min-h-screen text-gray-200 font-sans">
            <header className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700 p-4 sticky top-0 z-10">
                <div className="container mx-auto flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <LogoIcon className="h-8 w-8 text-cyan-400" />
                        <h1 className="text-xl font-bold text-white tracking-tight">AI Museum | Email-to-Web Demo</h1>
                    </div>
                </div>
            </header>

            <main className="container mx-auto p-4 md:p-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="lg:pr-4">
                        <div className="flex justify-between items-center mb-4 pb-2 border-b-2 border-gray-700">
                            <h2 className="text-2xl font-bold text-cyan-300">Demo Website</h2>
                            <button
                                onClick={handleResetContent}
                                className="flex items-center space-x-2 text-sm font-semibold text-gray-400 hover:text-white bg-gray-700/50 hover:bg-gray-700 px-3 py-1 rounded-md transition-colors duration-150"
                                aria-label="Reset website content to default"
                            >
                                <RefreshIcon className="h-4 w-4" />
                                <span>Reset</span>
                            </button>
                        </div>
                        <DemoWebsite content={content} />
                    </div>
                    <div>
                        <h2 className="text-2xl font-bold mb-4 pb-2 border-b-2 border-gray-700 text-teal-300">Simulated Email Editor</h2>
                        <EmailEditor
                            onSend={handleSendEmail}
                            isLoading={isLoading}
                            statusMessage={statusMessage}
                            clearStatus={() => setStatusMessage(null)}
                            resetCounter={editorResetCounter}
                        />
                    </div>
                </div>
            </main>

            <footer className="text-center p-4 text-gray-500 text-sm mt-8">
                <p>Powered by Gemini API. A demonstration of PRD "Mailpox Revival".</p>
            </footer>
        </div>
    );
};

export default App;